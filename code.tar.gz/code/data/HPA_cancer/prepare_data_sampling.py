#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import random
import numpy as np
import math
from sklearn.neighbors import DistanceMetric
from sklearn.metrics.pairwise import cosine_similarity
import random
import math


NUM_CLASSES = 6

label_map = {
    "Nuclear membrane": 0,
    "Nucleoli": 0,
    "Nucleoplasm": 0,
    "Nuclear speckles":0, # Nuclear speckles-Nucleoplasm
    "Nucleoli fibrillar center":0, #Nuclear speckles-Nucleoplasm
    "Nuclear bodies":0, #Nuclear bodies-Nucleoplasm
    "Cytosol": 1, # Cytoplasm-Cytosol
    "Rods & Rings":1,
    "Cytoplasmic bodies":1, #Cytoplasmic bodies -Cytosol
    "Intermediate filaments":1, #Intermediate filaments - Cytoplasm
    "Focal adhesion sites":1,#Focal adhesion sites -Cytoplasm
    "Cell Junctions": 1,#Cell Junctions-Plasma membrane
    "Microtubules": 1,# Microtubules -Cytoplasm
    "Cleavage furrow":1, #Cleavage furrow - Microtubules
    "Midbody": 1, #Midbody-Microtubules
    "Midbody ring":1, #Midbody ring -Microtubules
    "Mitotic spindle":1, # Mitotic spindle-Cytoplasm
    "Microtubule ends":1, #Microtubule ends -Cytoplasm
    "Centrosome":1, # Centrosome-Cytoplasm
    "Centriolar satellite":1, #Centriolar satellite -Cytoplasm
    "Plasma membrane": 1,
    "Actin filaments":1,# Actin filaments -Cytoplasm
    "Cytokinetic bridge":1, #Cytokinetic bridge-Cytoplasm                            
    "Vesicles": 2,
    "Endosomes":2,
    "Peroxisomes":2, #Peroxisomes-Vesicles
    "Lysosomes":2, #Endosomes;Lysosomes - Vesicles
    "Lipid droplets":2, #Lipid droplets-Vesicles                
    "Mitochondria": 3,
    "Golgi apparatus": 4,
    "Endoplasmic reticulum": 5
}


four_tissue_list = ['bladder', 'breast', 'liver','prostate']

def get_gene_list(tissue):
    prefix = 'fv/'+ tissue + '/' 
    canpath = prefix + 'cancer/protein/res18_128/'
    norpath = prefix + 'normal/protein/res18_128/'
    cangene = os.listdir(canpath)
    norgene = os.listdir(norpath)
    gene_list = np.intersect1d(norgene, cangene)
    genes = []
    for gene_i in gene_list:
        genes.append(gene_i.split('.')[0])
    return(genes)

def get_enhanced_gene(tissue):
    gene_file = 'Adjacent/'+tissue+'/gene_list'
    genes=[]
    with open(gene_file, 'r') as f:
        for line in f.readlines():
            gene = line.strip("\n")
            genes.append(gene)
    return genes

def _load_label_from_file(tissue,Gene):
    d = {}
    label_dict ={}
    fname = tissue + '_gene_labels'
    label_file = os.path.join('labels', fname)
    with open(label_file, 'r') as f:
        for line in f.readlines():
            gene, label = line.strip("\n").split("\b")
            labels = [label_map[x] for x in label.split(";") if x]
            labels = list(set(labels))
            if labels:
                d[gene] = labels

    for gene_i in Gene:
        gene_i = gene_i.split('.')[0]
        if gene_i in d:
            label_dict[gene_i] = d[gene_i]
        else:
            label_dict[gene_i] = []
    return label_dict

if __name__ == "__main__":
    four_tissue_list = ['Bladder'] #'Liver', 'Prostate','Bladder','Breast'
    for tissue in four_tissue_list:
        print(tissue)
        Gene = get_enhanced_gene(tissue)
        print(len(Gene))

        Gene_Label = _load_label_from_file(tissue, Gene)
        print(len(Gene_Label))

        fv_loader = 'res18_128'# 'res18_512'
        method = 'dist' 
        estimates = 35
        states = ['normal','cancer']
        for state in states:
            print(state)
            for esti in range(estimates):
                print('esti',esti)
                graph_indicator = []
                fv_img = []
                graph_labels = []
                per_proein_img_number = []
                adj_weight_list = []
                for i in range(len(Gene)):
                    gene_i=Gene[i]
                    gene_i_label = Gene_Label[gene_i]
                    graph_labels.append(gene_i_label)

                    #node feature
                    prefix = tissue+'/'+ state +'/protein/'
                    fv_path = 'fv/'+ prefix + fv_loader+'/'+ gene_i +'.npy'
                    fv_protein = np.load(fv_path) #(img_number, 512)
                    if np.shape(fv_protein)[0]<3:
                        fv_protein = fv_protein
                    else:
                        np.random.shuffle(fv_protein)
                        np.random.shuffle(fv_protein)
                        num = 2/3 * np.shape(fv_protein)[0]
                        num = math.ceil(num)
                        fv_protein = fv_protein[0:num]
                    per_proein_img_number.append(np.shape(fv_protein)[0])
                    per_protein_img = []
                    for j in range(np.shape(fv_protein)[0]):
                        fv_img.append(fv_protein[j])
                        per_protein_img.append(fv_protein[j])
                        graph_indicator.append(i+1) # start from 1 
                    if method == 'dist':
                        dist = DistanceMetric.get_metric('euclidean')
                        Euclidean = dist.pairwise(np.array(per_protein_img))
                        adj = np.reciprocal(np.add(Euclidean,np.eye(np.shape(Euclidean)[0])))-np.eye(np.shape(Euclidean)[0])
                        adj_weight_list.append(adj)     

                save_path = 'Adjacent/'+prefix +'est' + str(esti)
                if not os.path.exists(save_path):
                    os.mkdir(save_path)
                save_path = 'Adjacent/'+prefix +'est' + str(esti) + '/'+ fv_loader +'_'+ method
                filename_adj_weight = save_path + '_A.npy'
                filename_graph_indic = save_path +'_graph_indicator.npy'
                filename_graph_labels = save_path + '_graph_labels.npy'
                filename_node_attrs = save_path + '_node_attributes.npy'
                filename_per_proein_img_number = save_path + '_per_protein_img_number.npy'

                np.save(filename_adj_weight,np.array(adj_weight_list))
                np.save(filename_graph_indic,np.array(graph_indicator))
                np.save(filename_graph_labels,np.array(graph_labels))
                np.save(filename_node_attrs,np.array(fv_img))
                np.save(filename_per_proein_img_number,np.array(per_proein_img_number))

                print(len(adj_weight_list)) # graph number
                print(len(per_proein_img_number)) # graph number
                print(per_proein_img_number)
                print(len(graph_indicator)) #node number
                print(len(graph_labels)) # graph number
                print(len(fv_img)) # node number