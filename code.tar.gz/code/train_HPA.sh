
# res18_128, EUC distance
python -m train_HPA --adj_method=dist --bmname=res18_128 --hidden-dim=30 --output-dim=30 --cuda=0 --num-classes=6  --method=GNN